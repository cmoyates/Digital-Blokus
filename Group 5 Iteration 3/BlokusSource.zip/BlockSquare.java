import java.awt.*;

public class BlockSquare extends Button {

	BlockSquare[] TempHighlighting;
	
	public int playerUsing = 0;
	public Color playerColors[] = {this.getBackground(), Color.red, Color.blue, Color.green, Color.yellow};
	
	public void changePlayerUsing(int playerNum) 
	{
		playerUsing = playerNum;
		this.setBackground(playerColors[playerNum]);
	}
	
	//This function is used for demo purposes only.
	public void cyclePlayerUsing() 
	{
		changePlayerUsing((playerUsing + 1)%5);
	}
	
	public BlockSquare() throws HeadlessException {
		// TODO Auto-generated constructor stub
	}

	public BlockSquare(String label) throws HeadlessException {
		super(label);
		// TODO Auto-generated constructor stub
	}
}
