
/**
 * Write a description of class Game here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Game
{
    private int numPlayers;
    private int difficulty;
    private boolean colorDef;
    private boolean hints;
    private GUI newgame;
    private BoardUI boardUI;
    
    public Game()
    {
        newgame = new GUI(this);
        hints = true;
        boardUI = new BoardUI(this);
    }

    public void setNumPlayers(int num)
    {
        numPlayers = num;
    }
    
    public void setDifficulty(int diff)
    {
        difficulty = diff;
    }
    
    public void setColorDef(boolean col)
    {
        colorDef = col;
    }
    
    public void setHints(boolean hint)
    {
        hints = hint;
    }
    public void setHints(int hint)
    {
        hints = !(hint == 0);
    }
    
    public void setSettings(String set) 
    {
    	setNumPlayers(Integer.valueOf((set.substring(0,1))));
    	setDifficulty(Integer.valueOf((set.substring(1,2))));
    	setHints(Integer.valueOf((set.substring(2,3))));
    }
    
    public int getNumPlayers()
    {
        return this.numPlayers;
    }
    
    public int getDifficulty()
    {
        return this.difficulty;
    }
    
    public boolean getColour()
    {
        return this.colorDef;
    }
    
    public boolean getHints()
    {
        return this.hints;
    }
    
    public String getDifficultyString() 
    {
    	if (difficulty == 1) 
        {
        	return "Easy";
        }
        else if (difficulty == 2)
        {
        	return "Medium";
        }
        else 
        {
        	return "Hard";
        }
    }
    
    public String getSettings()
    {
    	String temp = String.valueOf(numPlayers) + String.valueOf(difficulty);
    	if(getHints()) 
    	{
    		temp = temp + "1";
    	}
    	else 
    	{
    		temp = temp + "0";
    	}
    	return temp;
    }
    
    public void startGame()
    {
        this.newgame.setupGUI();
    }
    
    public void DisplayBoard(boolean resuming) 
    {
    	boardUI.SetUp(resuming);
    }
}