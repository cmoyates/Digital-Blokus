import java.awt.*;
import java.io.*;
import javax.swing.*;

public class BoardUI 
{
	JFrame BoardWindow;
	JPanel BoardPanel;
	JPanel PiecesPanel;
	JPanel OptionsPanel;
	JButton CWRotate;
	JButton CCWRotate;
	JButton Flip;
	JToggleButton HintButton;
	JCheckBox EnableHints;
	BlockSquare tiles[][];
	Game game;
	
	public BoardUI(Game gameObject) 
	{
		// TODO Auto-generated constructor stub
		game = gameObject;
		BoardWindow = new JFrame("The Game");
		BoardWindow.addWindowListener(new java.awt.event.WindowAdapter() {
		    @Override
		    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
		        if (JOptionPane.showConfirmDialog(BoardWindow, 
		            "Would you like to save the game?", "Save?", 
		            JOptionPane.YES_NO_OPTION,
		            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION){
		        	RecordBoard();
		        }
		        System.exit(0);
		    }
		});
		BoardPanel = new JPanel();
		tiles = new BlockSquare[20][20];
		PiecesPanel = new JPanel();
		OptionsPanel = new JPanel();
		HintButton = new JToggleButton("");
		CWRotate = new JButton("⤾");
		CCWRotate = new JButton("⤿");
		Flip = new JButton("↔");
	}

	public void SetUp(boolean resuming) 
	{
		BoardWindow.setLayout(new BorderLayout());
		BoardWindow.setSize(1600, 900);
		
		BoardPanel.setSize(900,900);
		BoardPanel.setLayout(new GridLayout(20,20));
		
		for	(int i = 0; i < 400; i++) 
		{
			BlockSquare temp = new BlockSquare();
			temp.setSize(45, 45);
			temp.addActionListener(e -> ((BlockSquare) e.getSource()).cyclePlayerUsing());
			int index1 = ((i)/20);
			int index2 = ((i)%20);
			tiles[index1][index2] = temp;
			BoardPanel.add(temp);
		}
		
		if(resuming) {LoadBoard();}
		
		PiecesPanel.setSize(350,900);
		PiecesPanel.setLayout(new FlowLayout());
		PiecesPanel.setPreferredSize(new Dimension(350, 150));
		PiecesPanel.add(new JLabel("There are " + String.valueOf(game.getNumPlayers()) + " human players."));
		PiecesPanel.add(new JLabel("There are " + String.valueOf(4-game.getNumPlayers()) + " CPU players."));
		if (game.getDifficulty() != 0) 
		{
			PiecesPanel.add(new JLabel("Their difficulty has been set to " + game.getDifficultyString() + "."));
		}
		
		OptionsPanel.setSize(350,900);
		OptionsPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 14));
		OptionsPanel.setPreferredSize(new Dimension(350, 150));
		
		Font buttonFont = new Font("Dialog", Font.PLAIN, 140);

		HintButton.setPreferredSize(new Dimension(200,200));
		HintButton.setFont(new Font("Dialog", Font.BOLD, 27));
		HintButton.addActionListener(e -> UpdateHintButton());
		HintButton.setSelected(game.getHints());
		UpdateHintButton();

		CWRotate.setPreferredSize(new Dimension(200,200));
		CWRotate.setFont(buttonFont);
		
		CCWRotate.setPreferredSize(new Dimension(200,200));
		CCWRotate.setFont(buttonFont);
		
		Flip.setPreferredSize(new Dimension(200,200));
		Flip.setFont(buttonFont);
		OptionsPanel.add(HintButton);
		OptionsPanel.add(CWRotate);
		OptionsPanel.add(CCWRotate);
		OptionsPanel.add(Flip);
		
		BoardWindow.add(BoardPanel, BorderLayout.CENTER);
		BoardWindow.getContentPane().add(BorderLayout.WEST, new JScrollPane(PiecesPanel));
		BoardWindow.add(OptionsPanel, BorderLayout.EAST);
		BoardWindow.setLocationRelativeTo(null);
		BoardWindow.setVisible(true);
	}
	
	
	public void UpdateHintButton() 
	{
		if (HintButton.isSelected()) 
		{
			HintButton.setText("<html>Hints are being shown.");
			game.setHints(true);
		}
		else 
		{
			HintButton.setText("<html>Hints are not being shown.");
			game.setHints(false);
		}
	}
	
	public void RecordBoard()
	{
		String[] boardStrings = {"","","","","","","","","","","","","","","","","","","","",""};
		
		try {
            FileWriter writer = new FileWriter("MyFile.txt", false);
            writer.write("");
            writer.close();
        } 
		catch (IOException e) {
            e.printStackTrace();
        }
		
		for (int x = 0; x < 20; x++) 
		{
			for (int y = 0; y < 20; y++) 
			{
				boardStrings[x] = boardStrings[x] + Integer.toString(tiles[x][y].playerUsing); 
			}
			
			System.out.println(boardStrings[x]);
			try {
	            FileWriter writer = new FileWriter("MyFile.txt", true);
	            writer.write(boardStrings[x]);
	            writer.write("\r\n");
	            writer.close();
	        } 
			catch (IOException e) {
	            e.printStackTrace();
	        }
		}
		
		try {
            FileWriter writer = new FileWriter("MyFile.txt", true);
            writer.write(game.getSettings());
            writer.write("\r\n");
            writer.close();
        } 
		catch (IOException e) {
            //e.printStackTrace();
        }
	}
	
	
	
	public void LoadBoard() 
	{
		String[] saveString = new String[21];
		int counter2 = 0;
		
		try {
			BufferedReader br = new BufferedReader(new FileReader("MyFile.txt"));
			String st; 
			try {
				while ((st = br.readLine()) != null) {
					saveString[counter2] = st;
					counter2++;}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			try {
	            FileWriter writer = new FileWriter("MyFile.txt", false);
	            writer.write("");
	            writer.close();
	        } 
			catch (IOException a) {
	            //e.printStackTrace();
	        }
		} 
			
		if (saveString[0] != null) 
		{
			for (int i = 0; i < 20; i++) 
			{
				for (int j = 0; j < 20; j++) 
				{
					tiles[i][j].changePlayerUsing(Integer.parseInt(saveString[i].substring(j, j+1)));
				}
			}
		}
		
		game.setSettings(saveString[20]);
	}
}
