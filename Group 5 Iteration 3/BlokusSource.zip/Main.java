
public class Main {

	public static void main(String[] args)
    {
        Game newgame = new Game();
        newgame.startGame();
    }

}