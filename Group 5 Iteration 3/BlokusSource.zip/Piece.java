
public class Piece {

	
	public static int[][][] Pieces = {
	
			{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}
			
	};
	
	
	
	public Piece() {
		// TODO Auto-generated constructor stub
	}

}
