//This is the main class
public class Main {
	//This is the main method that gets called when the game runs
	public static void main(String[] args)
    {
        //These lines create a Game object and call the startGame function to start the game
		Game newgame = new Game();
        newgame.startGame();
    }
}