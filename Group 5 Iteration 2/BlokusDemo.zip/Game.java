
/**
 * Write a description of class Game here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Game
{
    private int numPlayers;
    private int difficulty;
    private boolean colourd;
    private boolean hints;
    private GUI newgame;
    
    public Game()
    {
        newgame = new GUI(this);
        hints = true;
    }

    public void setNumPlayers(int num)
    {
        this.numPlayers = num;
    }
    
    public void setDifficulty(int diff)
    {
        this.difficulty = diff;
    }
    
    public void setColour(boolean col)
    {
        this.colourd = col;
    }
    
    public void setHints(boolean hint)
    {
        this.hints = hint;
    }
    
    public int getNumPlayers()
    {
        return this.numPlayers;
    }
    
    public int getDifficulty()
    {
        return this.difficulty;
    }
    
    //This function is just for use in the limited release
    public String getDifficultyString() 
    {
    	if (difficulty == 1) 
        {
        	return "Easy";
        }
        else if (difficulty == 2)
        {
        	return "Medium";
        }
        else 
        {
        	return "Hard";
        }
    }
    
    public void startGame()
    {
        this.newgame.setupGUI();
    }
}
