import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class GUI extends JFrame implements ActionListener
{
    // instance variables - replace the example below with your own
    private int x;
    private JFrame setupScreen;
    private JFrame board;
    private JButton one, two, three, four, yes, no, on, off, easy, medium, hard, start;
    private Game game;
    /**
     * Constructor for objects of class GUI
     */
    public GUI(Game game)
    {
        this.game = game;
        this.setupScreen = new JFrame("New Game");
        this.board = new JFrame("Board");
        one = new JButton("");
        two = new JButton("");
        three = new JButton("");
        four = new JButton("");
        off = new JButton("");
        on  = new JButton("");
        yes = new JButton("");
        no = new JButton("");
        easy = new JButton("");
        medium = new JButton("");
        hard = new JButton("");
        start = new JButton("Start");
        one.setText("1");
        two.setText("2");
        three.setText("3");
        four.setText("4");
        on.setText("On");
        off.setText("Off");
        easy.setText("Easy");
        medium.setText("Medium");
        hard.setText("Hard");
        yes.setText("Yes");
        no.setText("No");
    }

  
    public void setupGUI()
    {
        setupScreen.setSize(500, 600);
        setupScreen.setVisible(true);
        JLabel ins = new JLabel("Choose how many human players down below, and the difficulty to get started!");
        JLabel numof = new JLabel("Number of Players:");
        JLabel diff = new JLabel("Difficulty:");
        JLabel toggle = new JLabel("Use Hints?:");
        JLabel color = new JLabel("Do you have any colour deficiencies?:");
        JLabel imgLabel = new JLabel(new ImageIcon(getClass().getResource("Blokus.jpg")));
        
        setupScreen.setLayout(null);
        setupScreen.getContentPane().setBackground(Color.WHITE);
        start.setBackground(Color.WHITE);
        setupScreen.setLocationRelativeTo(null);
        setupScreen.add(start);
        setupScreen.add(yes);
        setupScreen.add(no);
        setupScreen.add(color);
        setupScreen.add(on);
        setupScreen.add(off);
        setupScreen.add(toggle);
        setupScreen.add(easy);
        setupScreen.add(medium);
        setupScreen.add(hard);
        setupScreen.add(diff);
        setupScreen.add(one);
        setupScreen.add(two);
        setupScreen.add(three);
        setupScreen.add(four);
        setupScreen.add(numof);
        setupScreen.add(ins);
        setupScreen.add(imgLabel);
        imgLabel.setBounds(165,0, 160,88);
        start.setBounds(191, 420, 75, 60);
        ins.setBounds(25, 68, 450, 51);
        numof.setBounds(187, 105, 125, 25);
        diff.setBounds(210, 220, 125, 25);
        one.setBounds(65, 140, 75, 75);
        two.setBounds(150, 140, 75, 75);
        three.setBounds(235, 140, 75, 75);
        four.setBounds(320, 140, 75, 75);
        easy.setBounds(65,245, 100, 75);
        medium.setBounds(180, 245, 100, 75);
        hard.setBounds(295, 245, 100, 75);
        toggle.setBounds(70,340, 125, 25);
        on.setBounds(65,375, 75,75);
        off.setBounds(65, 460, 75,75);
        color.setBounds(250,340, 225, 25);
        yes.setBounds(315,375, 75, 75);
        no.setBounds(315, 460, 75, 75);
        on.setBorder(BorderFactory.createLineBorder(Color.gray, 5));
        no.setBorder(BorderFactory.createLineBorder(Color.gray, 5));
        
        one.setBackground(Color.RED);
        two.setBackground(Color.GREEN);
        three.setBackground(new Color(255, 240, 77));
        four.setBackground(Color.BLUE);
        one.setForeground(Color.WHITE);
        two.setForeground(Color.WHITE);
        three.setForeground(Color.WHITE);
        four.setForeground(Color.WHITE);
        easy.setBackground(Color.RED);
        medium.setBackground(Color.GREEN);
        hard.setBackground(Color.BLUE);
        easy.setForeground(Color.WHITE);
        medium.setForeground(Color.WHITE);
        hard.setForeground(Color.WHITE);
        on.setForeground(Color.WHITE);
        off.setForeground(Color.WHITE);
        yes.setForeground(Color.WHITE);
        no.setForeground(Color.WHITE);
        on.setBackground(Color.RED);
        off.setBackground(Color.BLUE);
        yes.setBackground(Color.BLACK);
        no.setBackground(Color.BLACK);
        one.setFocusable(false);
        two.setFocusable(false);
        three.setFocusable(false);
        four.setFocusable(false);
        on.setFocusable(false);
        off.setFocusable(false);
        yes.setFocusable(false);
        no.setFocusable(false);
        easy.setFocusable(false);
        medium.setFocusable(false);
        hard.setFocusable(false);
        start.setFocusable(false);
        one.setFont(new Font("Arial", Font.PLAIN, 40));
        two.setFont(new Font("Arial", Font.PLAIN, 40));
        three.setFont(new Font("Arial", Font.PLAIN, 40));
        four.setFont(new Font("Arial", Font.PLAIN, 40));
        easy.setFont(new Font("Arial", Font.BOLD, 15));
        medium.setFont(new Font("Arial", Font.BOLD, 17));
        hard.setFont(new Font("Arial", Font.BOLD, 15));
        yes.setFont(new Font("Arial", Font.BOLD, 20));
        no.setFont(new Font("Arial", Font.BOLD, 20));
        on.setFont(new Font("Arial", Font.BOLD, 20));
        off.setFont(new Font("Arial", Font.BOLD, 20));
        ins.setFont(new Font("Arial", Font.BOLD, 12));
        
        one.addActionListener(this);
        two.addActionListener(this);
        three.addActionListener(this);
        four.addActionListener(this);
        on.addActionListener(this);
        off.addActionListener(this);
        easy.addActionListener(this);
        medium.addActionListener(this);
        hard.addActionListener(this);
        yes.addActionListener(this);
        no.addActionListener(this);
        start.addActionListener(this);
    }
 
    public void openSetupGUI()
    {
        setupScreen.setVisible(true);
    }
    
    public void closeSetupGUI()
    {
        setupScreen.setVisible(false);
    }
    
    public void openBoardGUI()
    {
        if(this.game.getNumPlayers() == 0 || this.game.getDifficulty() == 0)
        {
            JFrame error = new JFrame("Warning!");
            error.setSize(500,100);
            JLabel message = new JLabel("You have to pick a number of players and a difficulty to start");
            error.add(message);
            error.setLocationRelativeTo(null);
            error.setVisible(true);
        }
        else{
        closeSetupGUI();
        setUpBoard();
        }
    }
    
    public void setUpBoard()
    {
        this.board.setSize(500,500);
        board.setLocationRelativeTo(null);
        board.setVisible(true);
        JPanel b = new JPanel();
        JLabel future = new JLabel("THIS WILL BE THE BOARD.");
        //JLabel status = new JLabel("There will be " + Integer.toString(game.getNumPlayers()) + " players, and " + Integer.toString(4 - game.getNumPlayers()) + " CPU players. The difficulty of the CPU players will be \"" + game.getDifficultyString() + "\".");
        JLabel status = new JLabel("<html>The amount of human players is: " + Integer.toString(game.getNumPlayers()) + "<br>The amount of CPU players is: " + Integer.toString(4 - game.getNumPlayers()) + "<br>The difficulty of the CPU players will be: " + game.getDifficultyString() + "</html>");
        
        board.setLayout(null);
        board.add(future);
        board.add(status);
        b.setLayout(new GridLayout(0,1));
        board.add(b);
        future.setBounds(50,50,200,200);
        status.setBounds(50,70,400,300);
        b.setBounds(25,25,475,475);
        b.setBackground(Color.WHITE);
    }
    
    public void actionPerformed(ActionEvent e)
    {
        JButton button = (JButton) e.getSource();
        if(button.getText() == "1")
        {
            this.game.setNumPlayers(1);
            button.setBorder(BorderFactory.createLineBorder(Color.gray, 5));
            this.two.setBorder(BorderFactory.createEmptyBorder());
            three.setBorder(BorderFactory.createEmptyBorder());
            four.setBorder(BorderFactory.createEmptyBorder());
        }
        else if(button.getText() == "2")
        {
            this.game.setNumPlayers(2);
            button.setBorder(BorderFactory.createLineBorder(Color.gray, 5));
            one.setBorder(BorderFactory.createEmptyBorder());
            three.setBorder(BorderFactory.createEmptyBorder());
            four.setBorder(BorderFactory.createEmptyBorder());
        }
        else if(button.getText() == "3")
        {
            this.game.setNumPlayers(3);
            button.setBorder(BorderFactory.createLineBorder(Color.gray, 5));
            two.setBorder(BorderFactory.createEmptyBorder());
            one.setBorder(BorderFactory.createEmptyBorder());
            four.setBorder(BorderFactory.createEmptyBorder());
        }
        else if(button.getText() == "4")
        {
            this.game.setNumPlayers(4);
            button.setBorder(BorderFactory.createLineBorder(Color.gray, 5));
            two.setBorder(BorderFactory.createEmptyBorder());
            three.setBorder(BorderFactory.createEmptyBorder());
            one.setBorder(BorderFactory.createEmptyBorder());
        }
        else if(button.getText() == "Easy")
        {
            this.game.setDifficulty(1);
            button.setBorder(BorderFactory.createLineBorder(Color.gray, 5));
            medium.setBorder(BorderFactory.createEmptyBorder());
            hard.setBorder(BorderFactory.createEmptyBorder());
        }
        else if(button.getText() == "Medium")
        {
            this.game.setDifficulty(2);
            button.setBorder(BorderFactory.createLineBorder(Color.gray, 5));
            easy.setBorder(BorderFactory.createEmptyBorder());
            hard.setBorder(BorderFactory.createEmptyBorder());
        }
        else if(button.getText() == "Hard")
        {
            this.game.setDifficulty(3);
            button.setBorder(BorderFactory.createLineBorder(Color.gray, 5));
            medium.setBorder(BorderFactory.createEmptyBorder());
            easy.setBorder(BorderFactory.createEmptyBorder());
        }
        else if(button.getText() == "On")
        {
            this.game.setHints(true);
            button.setBorder(BorderFactory.createLineBorder(Color.gray, 5));
            off.setBorder(BorderFactory.createEmptyBorder());
        }
        else if(button.getText() == "Off")
        {
            this.game.setHints(false);
            button.setBorder(BorderFactory.createLineBorder(Color.gray, 5));
            on.setBorder(BorderFactory.createEmptyBorder());
        }
        else if(button.getText() == "Yes")
        {
            this.game.setColour(true);
            button.setBorder(BorderFactory.createLineBorder(Color.gray, 5));
            no.setBorder(BorderFactory.createEmptyBorder());
            one.setBackground(Color.BLACK);
            two.setBackground(Color.BLACK);
            three.setBackground(Color.BLACK);
            four.setBackground(Color.BLACK);
            on.setBackground(Color.BLACK);
            off.setBackground(Color.BLACK);
            easy.setBackground(Color.BLACK);
            medium.setBackground(Color.BLACK);
            hard.setBackground(Color.BLACK);
        }
        else if(button.getText() == "No")
        {
            this.game.setColour(false);
            button.setBorder(BorderFactory.createLineBorder(Color.gray, 5));
            yes.setBorder(BorderFactory.createEmptyBorder());
            one.setBackground(Color.RED);
            two.setBackground(Color.GREEN);
            three.setBackground(new Color(255, 240, 77));
            four.setBackground(Color.BLUE);
            on.setBackground(Color.RED);
            off.setBackground(Color.BLUE);
            easy.setBackground(Color.RED);
            medium.setBackground(Color.GREEN);
            hard.setBackground(Color.BLUE);
        }
        else if(button.getText() == "Start")
        {
            openBoardGUI();
        }
    }
}
