import java.awt.Color;

public class CPUPlayer extends Player{

	int difficulty;
	//DifficultyAI ai;
	
	
	CPUPlayer(int playerNumParam, Color colorParam, String charParam, int difficultyParam) {
		super(playerNumParam, colorParam, charParam);
		// TODO Auto-generated constructor stub
		difficulty = difficultyParam;
		setAI(new DifficultyAI(difficultyParam, true));
		
	}
	
	public int GetDifficulty() 
	{
		return difficulty;
	}
	
	
	
	
}
