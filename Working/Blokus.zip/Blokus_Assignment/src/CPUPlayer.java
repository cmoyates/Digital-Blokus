import java.awt.Color;

public class CPUPlayer extends Player{

	int difficulty;
	
	CPUPlayer(int playerNumParam, Color colorParam, String charParam, int difficultyParam) {
		super(playerNumParam, colorParam, charParam);
		// TODO Auto-generated constructor stub
		difficulty = difficultyParam;
	}
	
	public int GetDifficulty() 
	{
		return difficulty;
	}
}
