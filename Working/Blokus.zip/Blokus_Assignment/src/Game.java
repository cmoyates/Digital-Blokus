//This is the Game class, it handles most of the things that need to be accessed by multiple other classes
public class Game
{
    //These lines declare all of the necessary variables
	private int numPlayers;
    private int difficulty;
    private boolean colorDef;
    private boolean hints;
    private MenuUI menuUI;
    private BoardUI boardUI;
    
    //This is the constructor for this class
    public Game()
    {
    	//These line initialize a few of the variables
    	menuUI = new MenuUI(this);
        hints = true;
        boardUI = new BoardUI(this);
    }

    //These are all of the setters for the variables that need them
    public void setNumPlayers(int num)
    {
        numPlayers = num;
    }
    public void setDifficulty(int diff)
    {
        difficulty = diff;
    }
    public void setColorDef(boolean col)
    {
        colorDef = col;
    }
    public void setHints(boolean hint)
    {
        hints = hint;
    }
    
    //This is a special setter that takes a single string and sets several other variables accordingly
    public void setSettings(String set) 
    {
    	setNumPlayers(Integer.valueOf((set.substring(0,1))));
    	setDifficulty(Integer.valueOf((set.substring(1,2))));
    	setHints(Integer.valueOf((set.substring(2,3))) != 0);
    }
    
    //These are all of the getters for the variables that need them
    public int getNumPlayers()
    {
        return this.numPlayers;
    }
    public int getDifficulty()
    {
        return this.difficulty;
    }
    public boolean getColour()
    {
        return this.colorDef;
    }
    public boolean getHints()
    {
        return this.hints;
    }
    
    //This is a special getter that returns the value of the difficulty variable as a string that states what the int corresponds to
    public String getDifficultyString() 
    {
    	if (difficulty == 1) 
        {
        	return "Easy";
        }
        else if (difficulty == 2)
        {
        	return "Medium";
        }
        else 
        {
        	return "Hard";
        }
    }
    
    //This is a special getter that gets a string that represents the current values of multiple variables
    public String getSettings()
    {
    	String temp = String.valueOf(numPlayers) + String.valueOf(difficulty);
    	if(getHints()) 
    	{
    		temp = temp + "1";
    	}
    	else 
    	{
    		temp = temp + "0";
    	}
    	return temp;
    }
    
    //This is a method that opens the UI for the main menu
    public void startGame()
    {
        menuUI.setupGUI();
    }
    
    //This is a method that opens the UI for the actual game board
    public void DisplayBoard(boolean resuming) 
    {
    	boardUI.SetUp(resuming);
    }
}