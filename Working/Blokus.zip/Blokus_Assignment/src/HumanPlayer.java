import java.awt.Color;

public class HumanPlayer extends Player{

	HumanPlayer(int playerNumParam, Color colorParam, String charParam) {
		super(playerNumParam, colorParam, charParam);
		// TODO Auto-generated constructor stub
	}

}
