import java.awt.Color;

public class Player 
{
	int playerNumber;
	Color blockColor;
	String blockChar;
	boolean blocksAvailable[];
	final boolean allBlocksAvailable[] = {true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true};
	
	Player(int playerNumParam, Color colorParam, String charParam)
	{
		blockColor = colorParam;
		blockChar = charParam;
		playerNumber = playerNumParam;
		blocksAvailable = allBlocksAvailable;
	}
	
	public void pieceUsed(int index) 
	{
		blocksAvailable[index] = false;
	}
	
	public Color getColor() 
	{
		return blockColor;
	}
	
	public String getChar() 
	{
		return blockChar;
	}
	
	public String getAvailablePiecesString() 
	{
		String tempString = "";
		for (int i = 0; i < 21; i++) 
		{
			if (blocksAvailable[i]) 
			{
				tempString = tempString + "1";
			}
			else 
			{
				tempString = tempString + "0";
			}
		}
		return tempString;
	}
	
	public boolean[] getAvailablePieces() 
	{
		return blocksAvailable;
	}
	
	public int getPlayerNumber() 
	{
		return playerNumber;
	}
}
