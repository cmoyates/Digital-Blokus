import java.awt.*;

//This is the class for the squares that appear on the board
public class BlockSquare extends Button {
	
	//These lines of code initialize and declare a couple of variables
	public int playerUsing = 0;
	public Color playerColors[] = {this.getBackground(), Color.red, Color.blue, Color.green, Color.yellow};
	public int coords[];
	public BlockSquare fiveSurround[][] = null;
	
	//This is a method that is used to change the player that has placed a piece on this particular square
	public void changePlayerUsing(int playerNum) 
	{
		playerUsing = playerNum;
		this.setBackground(playerColors[playerNum]);
	}
	
	//This function is used for demo purposes only, it cycles through all of the possible players that can be using this square
	public void cyclePlayerUsing() 
	{
		changePlayerUsing((playerUsing + 1)%5);
	}
	
	public BlockSquare(int xCoord, int yCoord) 
	{
		coords = new int[] {xCoord, yCoord};
	}
	
	public int[] getCoords() 
	{
		return coords;
	}
	
	public BlockSquare[][] getFiveSurround() 
	{
		return fiveSurround;
	}
	public BlockSquare getFiveSurroundIndex(int xCoord, int yCoord) 
	{
		return fiveSurround[xCoord][yCoord];
	}
	
	public void setFiveSurround(BlockSquare[][] squares) 
	{
		fiveSurround = squares;
	}
	public void setFiveSurround(BlockSquare square, int xCoord, int yCoord) 
	{
		fiveSurround[xCoord][yCoord] = square;
	}
	
	public Color getPlayerColor() 
	{
		return playerColors[playerUsing];
	}
	
	public int getPlayerUsing() 
	{
		return playerUsing;
	}
}
