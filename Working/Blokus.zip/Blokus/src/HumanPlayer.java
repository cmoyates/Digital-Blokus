import java.awt.Color;

public class HumanPlayer extends Player{

	boolean firstTryFlag = false;
	
	HumanPlayer(int playerNumParam, Color colorParam, String charParam) {
		super(playerNumParam, colorParam, charParam);
		// TODO Auto-generated constructor stub
		setAI(new DifficultyAI(2, false));
	}

	public int decideOnPiece() 
	{
		if (!firstTryFlag) 
		{
			return ai.firstMove((this.getAvailablePieces()));
		}
		else 
		{
			return ai.subsequentMove();
		}
		
	}
	
	public void placed() 
	{
		firstTryFlag = false;
	}
}
